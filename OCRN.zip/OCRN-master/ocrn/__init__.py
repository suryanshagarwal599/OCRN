#To treat the current directory as a module
